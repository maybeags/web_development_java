package c15_casting.centralcontroll;

public interface Power {
    void on();

    void off();
}
